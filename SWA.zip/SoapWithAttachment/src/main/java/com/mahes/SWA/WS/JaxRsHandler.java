package com.mahes.SWA.WS;

import java.io.IOException;
import java.util.Enumeration;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

/**
 * Servlet implementation class JaxRsHandler
 */
public class JaxRsHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JaxRsHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		MimeHeaders mimeHeaders = new MimeHeaders();
		Enumeration<?> en = request.getHeaderNames();

		while (en.hasMoreElements()) {
			String headerName = (String) en.nextElement();
			String headerVal = request.getHeader(headerName);
			StringTokenizer tk = new StringTokenizer(headerVal, ",");
			while (tk.hasMoreTokens()) {
				mimeHeaders.addHeader(headerName, tk.nextToken().trim());
			}
		}

		MessageFactory factory = null;
		try {
			factory = MessageFactory.newInstance();
		} catch (SOAPException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		SOAPMessage message = null;
		try {
			message = factory.createMessage(mimeHeaders, request.getInputStream());
		} catch (SOAPException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		java.util.Iterator iterator = message.getAttachments();
		while (iterator.hasNext()) {
			AttachmentPart attachment = (AttachmentPart) iterator.next();
			String id = attachment.getContentId();
			String type = attachment.getContentType();
			System.out.print("Attachment " + id + " has content type " + type);
			if (type == "text/plain") {
				Object content = null;
				try {
					content = attachment.getContent();
				} catch (SOAPException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Attachment " + "contains:\n" + content);
			}
		}

	}
	}


