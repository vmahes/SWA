package com.mahes.SWA.WS;

import java.rmi.RemoteException;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.SOAPException;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

@WebService
public interface FileManager{

	@WebMethod
	//public void ReceiveAttachment(SOAPMessageContext context) throws RemoteException, SOAPException;
	public void ReceiveAttachment(AttachmentPart attachment);
}
