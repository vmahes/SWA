package com.mahes.SWA.WS;

import java.rmi.RemoteException;
import java.util.Set;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.namespace.QName;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPMessageContext;

@WebService(endpointInterface = "com.mahes.SWA.WS.FileManager", serviceName = "FileManager")
public class FileManagerImpl implements FileManager {

	AttachmentPart impl = null;

	public void ReceiveAttachment(AttachmentPart attachment) {
		// TODO Auto-generated method stub

	}
}
